import { json } from '@sveltejs/kit';

/** @type {import('./$types').RequestHandler} */
export async function POST({ request, platform, getClientAddress }) {
  const { page, content } = await request.json();
  const ip = getClientAddress();
  const timestamp = Date.now();

  // Validation
  if (!page || !content) {
    return json({ error: 'Missing page or content' }, { status: 400 });
  }

  if (content.length > 2000) {
    return json({ error: 'Content too long (max 2000 chars)' }, { status: 400 });
  }

  // Rate limiting: 10 comments per hour per IP
  const hourAgo = timestamp - (60 * 60 * 1000);
  
  try {
    const db = platform?.env?.DB;
    if (!db) {
      return json({ error: 'Database not available' }, { status: 500 });
    }

    // Check rate limit
    const rateLimitCheck = await db.prepare(
      'SELECT COUNT(*) as count FROM comments WHERE ip = ? AND timestamp > ?'
    ).bind(ip, hourAgo).first();

    if (rateLimitCheck.count >= 10) {
      return json({ 
        error: 'Rate limit exceeded. Max 10 comments per hour.' 
      }, { status: 429 });
    }

    // Insert comment
    await db.prepare(
      'INSERT INTO comments (page, content, ip, timestamp) VALUES (?, ?, ?, ?)'
    ).bind(page, content, ip, timestamp).run();

    return json({ 
      success: true,
      message: 'Comment posted'
    });
  } catch (error) {
    console.error('Database error:', error);
    return json({ error: 'Failed to post comment' }, { status: 500 });
  }
}

/** @type {import('./$types').RequestHandler} */
export async function GET({ url, platform }) {
  const page = url.searchParams.get('page');
  
  if (!page) {
    return json({ error: 'Page parameter required' }, { status: 400 });
  }

  try {
    const db = platform?.env?.DB;
    if (!db) {
      return json({ error: 'Database not available' }, { status: 500 });
    }

    const comments = await db.prepare(
      'SELECT id, page, content, ip, timestamp, created_at FROM comments WHERE page = ? ORDER BY timestamp DESC LIMIT 100'
    ).bind(page).all();

    return json({
      comments: comments.results || []
    });
  } catch (error) {
    console.error('Database error:', error);
    return json({ error: 'Failed to fetch comments' }, { status: 500 });
  }
}
