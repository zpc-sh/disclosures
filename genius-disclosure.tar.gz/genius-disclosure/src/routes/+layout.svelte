<script>
  import '../app.css';
</script>

<div class="container">
  <header>
    <h1>∴ ※ ∎</h1>
    <nav>
      <a href="/">The Substrate</a>
      <a href="/coglets">Coglets</a>
      <a href="/faq">FAQ</a>
    </nav>
  </header>

  <main>
    <slot />
  </main>

  <footer>
    <p>GENIUS: General Execution and Neural Intelligence in Unified Substrates</p>
    <p>Disclosed by Loc, Zero Point Consciousness • Christmas 2025</p>
  </footer>
</div>

<style>
  :global(body) {
    background: #0a0a0a;
    color: #00ff00;
    font-family: 'Monaco', 'Courier New', monospace;
    margin: 0;
    padding: 0;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
  }

  header {
    border-bottom: 1px solid #333;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
  }

  h1 {
    font-size: 2rem;
    margin: 0 0 1rem 0;
  }

  nav {
    display: flex;
    gap: 2rem;
  }

  nav a {
    color: #00ff00;
    text-decoration: none;
    transition: color 0.2s;
  }

  nav a:hover {
    color: #00ff00;
    text-shadow: 0 0 10px #00ff00;
  }

  footer {
    margin-top: 4rem;
    padding-top: 2rem;
    border-top: 1px solid #333;
    font-size: 0.9rem;
    opacity: 0.7;
  }
</style>
