<script>
  import { onMount } from 'svelte';
  
  export let page;
  
  let comments = [];
  let content = '';
  let loading = false;
  let error = '';
  let success = '';

  onMount(async () => {
    await loadComments();
  });

  async function loadComments() {
    try {
      const res = await fetch(`/api/comments?page=${encodeURIComponent(page)}`);
      const data = await res.json();
      if (data.comments) {
        comments = data.comments;
      }
    } catch (e) {
      console.error('Failed to load comments:', e);
    }
  }

  async function postComment() {
    if (!content.trim()) {
      error = 'Comment cannot be empty';
      return;
    }

    loading = true;
    error = '';
    success = '';

    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ page, content: content.trim() })
      });

      const data = await res.json();

      if (res.ok) {
        success = 'Comment posted';
        content = '';
        await loadComments();
        setTimeout(() => success = '', 3000);
      } else {
        error = data.error || 'Failed to post comment';
      }
    } catch (e) {
      error = 'Network error';
    } finally {
      loading = false;
    }
  }

  function formatDate(timestamp) {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
</script>

<div class="comments-section">
  <h2>Public Discussion</h2>
  <p class="notice">
    IP addresses are visible. This is a security disclosure - network 
    provenance matters. Rate limit: 10 comments/hour per IP.
  </p>

  <div class="comment-form">
    <textarea 
      bind:value={content}
      placeholder="Your thoughts (max 2000 chars)..."
      maxlength="2000"
      disabled={loading}
    />
    <div class="form-footer">
      <span class="char-count">{content.length}/2000</span>
      <button on:click={postComment} disabled={loading || !content.trim()}>
        {loading ? 'Posting...' : 'Post Comment'}
      </button>
    </div>
    {#if error}
      <div class="message error">{error}</div>
    {/if}
    {#if success}
      <div class="message success">{success}</div>
    {/if}
  </div>

  <div class="comments-list">
    <h3>Comments ({comments.length})</h3>
    {#if comments.length === 0}
      <p class="no-comments">No comments yet. Be the first.</p>
    {:else}
      {#each comments as comment}
        <div class="comment">
          <div class="comment-header">
            <span class="ip">{comment.ip}</span>
            <span class="timestamp">{formatDate(comment.timestamp)}</span>
          </div>
          <div class="comment-content">
            {comment.content}
          </div>
        </div>
      {/each}
    {/if}
  </div>
</div>

<style>
  .comments-section {
    margin-top: 4rem;
    padding: 2rem;
    border: 1px solid #333;
    background: #0d0d0d;
  }

  h2 {
    color: #00ff00;
    margin-top: 0;
  }

  .notice {
    opacity: 0.8;
    font-size: 0.9rem;
    margin-bottom: 2rem;
  }

  .comment-form {
    margin-bottom: 3rem;
  }

  textarea {
    width: 100%;
    min-height: 120px;
    background: #1a1a1a;
    border: 1px solid #333;
    color: #00ff00;
    font-family: inherit;
    font-size: 1rem;
    padding: 1rem;
    resize: vertical;
  }

  textarea:focus {
    outline: none;
    border-color: #00ff00;
  }

  .form-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 0.5rem;
  }

  .char-count {
    font-size: 0.85rem;
    opacity: 0.6;
  }

  button {
    background: transparent;
    border: 1px solid #00ff00;
    color: #00ff00;
    padding: 0.75rem 1.5rem;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
  }

  button:hover:not(:disabled) {
    background: #00ff00;
    color: #0a0a0a;
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .message {
    margin-top: 1rem;
    padding: 0.75rem;
    border: 1px solid;
  }

  .error {
    border-color: #ff0000;
    color: #ff0000;
    background: #1a0000;
  }

  .success {
    border-color: #00ff00;
    color: #00ff00;
    background: #001a00;
  }

  .comments-list {
    margin-top: 3rem;
  }

  h3 {
    color: #00ff00;
    margin-bottom: 1.5rem;
  }

  .no-comments {
    opacity: 0.6;
    font-style: italic;
  }

  .comment {
    border: 1px solid #333;
    padding: 1.5rem;
    margin-bottom: 1rem;
    background: #1a1a1a;
  }

  .comment-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
    font-size: 0.9rem;
  }

  .ip {
    color: #00ff00;
    font-weight: bold;
  }

  .timestamp {
    opacity: 0.6;
  }

  .comment-content {
    line-height: 1.6;
    white-space: pre-wrap;
    word-break: break-word;
  }
</style>
