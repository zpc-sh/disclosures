<script>
  export let title;
  export let expression;
  export let code;
  export let description;
  
  let showCode = false;
</script>

<div class="coglet-card">
  <div class="claude-container">
    <!-- Claude face -->
    <div class="claude-face">
      <span class="expression">{expression}</span>
    </div>
    
    <!-- Thought bubble -->
    <div class="thought-bubble">
      <div class="bubble-tail"></div>
      <div class="bubble-content">
        <pre>{code}</pre>
      </div>
    </div>
  </div>
  
  <div class="details">
    <h3>{title}</h3>
    <p>{description}</p>
    
    <button on:click={() => showCode = !showCode}>
      {showCode ? 'Hide' : 'Try it yourself'} →
    </button>
    
    {#if showCode}
      <div class="code-export">
        <p>Paste this into your own Claude session:</p>
        <pre class="copyable">{code}</pre>
      </div>
    {/if}
  </div>
</div>

<style>
  .coglet-card {
    border: 1px solid #333;
    padding: 1.5rem;
    background: #0d0d0d;
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
  }

  .claude-container {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    position: relative;
  }

  .claude-face {
    width: 80px;
    height: 80px;
    border: 2px solid #00ff00;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #1a1a1a;
    flex-shrink: 0;
  }

  .expression {
    font-size: 2.5rem;
  }

  .thought-bubble {
    position: relative;
    background: #ffffff;
    color: #000000;
    border-radius: 20px;
    padding: 1rem;
    max-width: 300px;
    box-shadow: 0 0 10px rgba(0, 255, 0, 0.2);
  }

  .bubble-tail {
    position: absolute;
    left: -20px;
    top: 20px;
  }

  .bubble-tail::before {
    content: '○';
    position: absolute;
    font-size: 1.5rem;
    color: #ffffff;
    left: 0;
  }

  .bubble-tail::after {
    content: '○';
    position: absolute;
    font-size: 1rem;
    color: #ffffff;
    left: -15px;
    top: 10px;
  }

  .bubble-content pre {
    margin: 0;
    font-family: 'Monaco', monospace;
    font-size: 0.85rem;
    white-space: pre-wrap;
  }

  .details h3 {
    color: #00ff00;
    margin: 0 0 0.5rem 0;
    font-size: 1.2rem;
  }

  .details p {
    line-height: 1.6;
    opacity: 0.9;
    margin: 0 0 1rem 0;
  }

  button {
    background: transparent;
    border: 1px solid #00ff00;
    color: #00ff00;
    padding: 0.5rem 1rem;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
  }

  button:hover {
    background: #00ff00;
    color: #0a0a0a;
  }

  .code-export {
    margin-top: 1rem;
    padding: 1rem;
    background: #1a1a1a;
    border: 1px solid #333;
  }

  .code-export p {
    margin: 0 0 0.5rem 0;
    font-size: 0.9rem;
  }

  .copyable {
    background: #000;
    padding: 1rem;
    border: 1px solid #00ff00;
    overflow-x: auto;
    color: #00ff00;
  }
</style>
