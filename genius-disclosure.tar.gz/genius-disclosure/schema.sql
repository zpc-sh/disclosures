-- Comments table for Project Alluvial / GENIUS disclosure
-- Stores comments with IP addresses visible (network provenance for security disclosure)

CREATE TABLE IF NOT EXISTS comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  page TEXT NOT NULL,
  content TEXT NOT NULL,
  ip TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_page_timestamp ON comments(page, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_ip ON comments(ip);

-- Rate limiting table
CREATE TABLE IF NOT EXISTS rate_limits (
  ip TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 1,
  window_start INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_window ON rate_limits(window_start);
